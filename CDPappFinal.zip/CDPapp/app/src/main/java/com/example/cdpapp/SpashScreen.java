package com.example.cdpapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.widget.ImageView;
import android.widget.TextView;

import com.airbnb.lottie.LottieAnimationView;

public class SpashScreen extends AppCompatActivity {

    TextView appname;
    LottieAnimationView lottie;
    ImageView defaultImage ;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_spash_screen);

        appname = findViewById(R.id.appname);
        lottie = findViewById(R.id.lottie);
        //defaultImage = findViewById(R.id.imageView);


        appname.animate().translationY(-1400).setDuration(2700).setStartDelay(0);
        lottie.animate().translationX(2000).setDuration(2000).setStartDelay(2900);

        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                Intent i = new Intent(getApplicationContext(),MainActivity.class);
                startActivity(i);
                //defaultImage.setImageResource(R.drawable.resource_default);
            }
        },3000);
    }
}
package com.example.cdpapp;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.Manifest;
import android.app.Dialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.media.ThumbnailUtils;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.Gallery;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.cdpapp.ml.Model;

import org.tensorflow.lite.DataType;
import org.tensorflow.lite.support.tensorbuffer.TensorBuffer;

import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;


public class MainActivity extends AppCompatActivity {

    Button camera, gallery;
    ImageView imageView;
    TextView result;
    TextView confidance;
    int imageSize = 256;
    Button solution;
    String strSolution ="";
    String strDiseaseName ="";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //View view = this.getWindow().getDecorView();
        //view.setBackgroundColor(112, 110, 250);

        camera = findViewById(R.id.btnTakePicture);
        gallery = findViewById(R.id.btnLaunchGallery);

        result = findViewById(R.id.result);
        imageView = findViewById(R.id.imageView);
        confidance= findViewById(R.id.classified2);

        solution = findViewById(R.id.btnSolution);

        imageView.setImageResource(R.drawable.resource_default);
        solution.setEnabled(false);


        camera.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
//                    Intent cameraIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
//                    startActivityForResult(cameraIntent,3);
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    if(checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED){
                        Intent cameraIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                        startActivityForResult(cameraIntent,3);
                    }else{
                        requestPermissions(new String[]{Manifest.permission.CAMERA},100);
                    }
                }
            }
        });

        gallery.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent cameraIntent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                startActivityForResult(cameraIntent,1);

            }
        });
    }
    public void classifyImage(Bitmap image){
        try {
            Model model = Model.newInstance(getApplicationContext());

            // Creates inputs for reference.
            TensorBuffer inputFeature0 = TensorBuffer.createFixedSize(new int[]{1, 256, 256, 3}, DataType.FLOAT32);
            ByteBuffer byteBuffer = ByteBuffer.allocateDirect(4* imageSize*imageSize*3);
            byteBuffer.order(ByteOrder.nativeOrder());

            int[] intValues = new int[imageSize*imageSize];

            image.getPixels(intValues,0,image.getWidth(),0,0,image.getWidth(), image.getHeight());

            int pixel=0;
            for(int i=0; i<imageSize; i++)
            {
                for(int j=0; j<imageSize;j++){
                    int val = intValues[pixel++];
                    byteBuffer.putFloat(((val >> 16) & 0xFF) * (1.f / 1));
                    byteBuffer.putFloat(((val >> 8) & 0xFF) * (1.f / 1));
                    byteBuffer.putFloat((val & 0xFF) * (1.f / 1));

                }
            }

            inputFeature0.loadBuffer(byteBuffer);

            // Runs model inference and gets result.
            Model.Outputs outputs = model.process(inputFeature0);
            TensorBuffer outputFeature0 = outputs.getOutputFeature0AsTensorBuffer();

            float[] confidences = outputFeature0.getFloatArray();
            // find the index of the class with the biggest confidence.
            int maxPos = 0;
            float maxConfidence = 0;
            for (int i = 0; i < confidences.length; i++) {
                if (confidences[i] > maxConfidence) {
                    maxConfidence = confidences[i];
                    maxPos = i;
                }
            }
            String[] classes = {"Early Blight", "Late Blight", "Healthy Plant"};
            if(maxPos==0)
                strSolution="1. To get rid of early blight, all of the affected leaves of the plant need to be removed. If all leaves on the plant are affected, you'll need to pull up the entire plant.\n" +
                        "2. Thoroughly spray the plant (bottoms of leaves also) with Bonide Liquid Copper Fungicide concentrate or Bonide Tomato & Vegetable";
            else if(maxPos==1)
                strSolution= "1. If there is some sign of blight and the potatoes are not mature, use Dithane (mancozeb) MZ or you can also use Tattoo C or Acrobat MZ. Acrobat used later in the season reduces late blight spores.\n" +
                        "2. Apply a copper based fungicide (2 oz/ gallon of water) every 7 days or less.";
            else
                strSolution ="Your Crops are Healthy :)";
            strDiseaseName = ""+classes[maxPos];
            result.setText("Classfied as : "+classes[maxPos]);
            confidance.setText("Confidence: "+maxConfidence);


            // for solution
            if(!TextUtils.isEmpty(strSolution)) {
                solution.setText("View Solution");
                solution.setEnabled(true);
            }
            // Releases model resources if no longer used.
            model.close();
        } catch (IOException e) {
            // TODO Handle the exception
        }

    }
    protected void onActivityResult(int requestCode, int resultCode,@Nullable Intent data){
        if(resultCode == RESULT_OK){
            if(requestCode == 3){
                Bitmap image = (Bitmap) data.getExtras().get("data");
                int dimension = Math.min(image.getWidth(), image.getHeight());
                image = ThumbnailUtils.extractThumbnail(image, dimension, dimension);
                imageView.setImageBitmap(image);

                image = Bitmap.createScaledBitmap(image, imageSize, imageSize, false);
                classifyImage(image);
            }else{
                Uri dat = data.getData();
                Bitmap image = null;
                try {
                    image = MediaStore.Images.Media.getBitmap(this.getContentResolver(), dat);
                } catch (IOException e) {
                    e.printStackTrace();
                }
                imageView.setImageBitmap(image);

                image = Bitmap.createScaledBitmap(image, imageSize, imageSize, false);
                classifyImage(image);
            }
        }
        super.onActivityResult(requestCode, resultCode, data);
    }

    @Override
    public void onBackPressed() {
        //super.onBackPressed();
    }

    public void viewSolution(View view) {
        Dialog dialog = new Dialog(this);
        dialog.setContentView(R.layout.dialog_box_customised);

        Button btnOk;
        TextView solution,DiseaseName;
        DiseaseName = dialog.findViewById(R.id.diseaseName);
        solution = dialog.findViewById(R.id.tvSolution);
        DiseaseName.setText(strDiseaseName);
        solution.setText(strSolution);

        btnOk = dialog.findViewById(R.id.btnOk);

        btnOk.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dialog.dismiss();
            }
        });
        dialog.show();
    }
}